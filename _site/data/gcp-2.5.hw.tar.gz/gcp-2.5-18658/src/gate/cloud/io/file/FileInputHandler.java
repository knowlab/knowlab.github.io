/*
 *  FileInputHandler.java
 *  Copyright (c) 2007-2011, The University of Sheffield.
 *
 *  This file is part of GCP (see http://gate.ac.uk/), and is free
 *  software, licenced under the GNU Affero General Public License,
 *  Version 3, November 2007.
 *
 *
 *  $Id: FileInputHandler.java 16610 2013-03-21 16:05:54Z valyt $ 
 */
package gate.cloud.io.file;

import static gate.cloud.io.IOConstants.*;
import gate.Document;
import gate.Factory;
import gate.FeatureMap;
import gate.Gate;
import gate.cloud.batch.DocumentID;
import gate.cloud.batch.PooledDocumentProcessor;
import gate.cloud.io.DocumentData;
import gate.cloud.io.IOConstants;
import gate.cloud.io.InputHandler;
import gate.cloud.util.GZIPURLStreamHandler;
import gate.util.GateException;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Map;

import org.apache.log4j.Logger;


/**
 * An input handler that creates GATE documents by reading files on disk. The 
 * document IDs are interpreted as /-separated paths, starting from the document
 * root.   
 */
public class FileInputHandler implements InputHandler {
  
  private static Logger logger = Logger.getLogger(FileInputHandler.class);
  
  /**
   * The file naming strategy used by this input handler.
   */
  protected NamingStrategy namingStrategy;
  
  /**
   * The mime type used when loading documents.
   */
  protected String mimeType;
  
  /**
   * The encoding used when loading documents.
   */
  protected String encoding;

  /**
   * The type of compression used (one of {@link IOConstants#VALUE_COMPRESSION_NONE}, or
   * {@link IOConstants#VALUE_COMPRESSION_GZIP}).
   */
  protected String compression;  
  
  /* (non-Javadoc)
   * @see gate.cloud.InputHandler#config(java.util.Map)
   */
  public void config(Map<String, String> configData) throws IOException, GateException {
    // naming strategy
    String namingStrategyClassName = configData.get(PARAM_NAMING_STRATEGY);
    if(namingStrategyClassName == null || namingStrategyClassName.length() == 0) {
      namingStrategyClassName = SimpleNamingStrategy.class.getName();
    }
    try {
      Class<? extends NamingStrategy> namingStrategyClass =
        Class.forName(namingStrategyClassName, true, Gate.getClassLoader())
               .asSubclass(NamingStrategy.class);
      namingStrategy = namingStrategyClass.newInstance();
      namingStrategy.config(false, configData);
    } catch(Exception e) {
      throw new GateException(
              "Could not instantiate specified naming strategy", e);
    }
    //compression
    compression = configData.get(PARAM_COMPRESSION);
    if(compression == null){
      compression = VALUE_COMPRESSION_NONE;
    }
    //encoding
    encoding = configData.get(PARAM_ENCODING);
    //mime type
    mimeType = configData.get(PARAM_MIME_TYPE);
  }
  
  /* (non-Javadoc)
   * @see gate.cloud.InputHandler#getInputDocument(java.lang.String)
   */
  public DocumentData getInputDocument(DocumentID id) throws IOException, GateException {
    File docFile = namingStrategy.toFile(id);
    FeatureMap params = Factory.newFeatureMap();
    URL docUrl = docFile.toURI().toURL();
    if(compression.equals(VALUE_COMPRESSION_GZIP)){
      docUrl = new URL(docUrl, "", new GZIPURLStreamHandler(docUrl));
    }
    
    params.put(Document.DOCUMENT_URL_PARAMETER_NAME, docUrl);
    if(mimeType != null && mimeType.length() > 0) {
      params.put(Document.DOCUMENT_MIME_TYPE_PARAMETER_NAME, mimeType);
    }
    if(encoding!= null && encoding.length() > 0){
      params.put(Document.DOCUMENT_ENCODING_PARAMETER_NAME, encoding);
    }
    
    params.put(Document.DOCUMENT_MARKUP_AWARE_PARAMETER_NAME, Boolean.TRUE);
    
    logger.debug("Loading document from file " + docFile);

    DocumentData docData = new DocumentData(
            (Document)Factory.createResource("gate.corpora.DocumentImpl",
                params, Factory.newFeatureMap(), id.toString()), id);
    docData.fileSize = docFile.length();
    return docData;
  }

  public void init() {
  }
  
  public void close() {
  }


  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    StringBuilder text = new StringBuilder();
    text.append("\n\tClass:           " + this.getClass().getName() + "\n");
    text.append(  "\tNaming strategy: " + namingStrategy + "\n");
    text.append(  "\tCompression:     " + compression + "\n");
    text.append(  "\tEncoding:        " + encoding + "\n");
    text.append(  "\tMime type:       " + mimeType + "\n");
    return text.toString();
  }
  
  
}
