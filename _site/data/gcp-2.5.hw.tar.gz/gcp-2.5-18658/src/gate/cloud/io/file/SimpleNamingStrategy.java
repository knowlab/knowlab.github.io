/*
 *  SimpleNamingStrategy.java
 *  Copyright (c) 2007-2011, The University of Sheffield.
 *
 *  This file is part of GCP (see http://gate.ac.uk/), and is free
 *  software, licenced under the GNU Affero General Public License,
 *  Version 3, November 2007.
 *
 *
 *  $Id: SimpleNamingStrategy.java 16612 2013-03-22 10:27:20Z valyt $ 
 */
package gate.cloud.io.file;

import static gate.cloud.io.IOConstants.PARAM_BATCH_FILE_LOCATION;
import static gate.cloud.io.IOConstants.PARAM_DOCUMENT_ROOT;
import static gate.cloud.io.IOConstants.PARAM_FILE_EXTENSION;
import gate.cloud.batch.DocumentID;
import gate.util.GateException;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Map;

public class SimpleNamingStrategy implements NamingStrategy {
  
  /**
   * The directory containing the batch specification file, or <code>null</code>
   * if the batch specification did not come from a file.
   */
  protected File batchDir;
  
  /**
   * The top-level directory containing the document files.   
   */
  protected URI documentRoot;
  
  /**
   * The file extension that should be appended to the ID.
   */  
  protected String fileExtension;

  public void config(boolean isOutput, Map<String, String> configData) throws IOException,
          GateException {
    //doc root
    String docRootStr = configData.get(PARAM_DOCUMENT_ROOT);
    if(docRootStr == null || docRootStr.trim().length() == 0){
      throw new IllegalArgumentException(
              "No value was provided for the required parameter \"" +
              PARAM_DOCUMENT_ROOT + "\"!");
    }
    String batchFileStr = configData.get(PARAM_BATCH_FILE_LOCATION);
    if(batchFileStr != null) {
      batchDir = new File(batchFileStr).getParentFile();
    }
    File documentRootFile = new File(docRootStr);
    if(!documentRootFile.isAbsolute()) {
      documentRootFile = new File(batchDir, docRootStr);
    }
    
    // sanity checks
    if(isOutput) {
      if(documentRootFile.exists()) {
        if(documentRootFile.isDirectory()) {
          // all OK
        } else {
          throw new IOException(documentRootFile.getAbsolutePath()
                  + " already exists and is not a directory!");
        }
      } else {
        // try and create it
        if(!documentRootFile.mkdirs()) { throw new IOException("Could not create "
                + documentRootFile.getAbsolutePath() + " directory!"); }
      } 
    } else {
      if(!documentRootFile.exists()){
        throw new IllegalArgumentException(
                "Directory \"" + documentRootFile + 
                "\", provided as value for required parameter \"" +
                PARAM_DOCUMENT_ROOT + "\", does not exist!");
      }
      if(!documentRootFile.isDirectory()){
        throw new IllegalArgumentException(
                "File \"" + documentRootFile + 
                "\", provided as value for required parameter \"" +
                PARAM_DOCUMENT_ROOT + "\", is not a directory!");
      }
    }
    
    documentRoot = documentRootFile.toURI();
    // sanity check - directory URIs must end with a slash
    if(!documentRoot.toString().endsWith("/")) {
      documentRoot = URI.create(documentRoot.toString() + "/");
    }
    
    //extension
    fileExtension = configData.get(PARAM_FILE_EXTENSION);
  }

  public File toFile(DocumentID id) throws IOException {
    try {
      String path = relativePathFor(id);
      if(fileExtension != null) {
        path += fileExtension;
      }
      URI u = new URI(null, null, path, null);
      URI docUri = documentRoot.resolve(u);
      return new File(docUri);
    } catch(URISyntaxException e) {
      throw (IOException)new IOException(
              "Could not determine file for ID " + id).initCause(e);
    }
  }
  
  /**
   * Converts a document ID into relative file path.  The value returned
   * from this method will have the configured file extension (if any)
   * appended to it and will then be treated as a relative URI and
   * resolved against the configured document root.
   * 
   * This implementation simply returns the document ID unchanged,
   * subclasses may wish to implement more sophisticated mappings.
   * 
   * @param id the document ID
   * @return a path suitable for use as a relative URI.
   */
  protected String relativePathFor(DocumentID id) {
    return id.getIdText();
  }
  
  public String toString() {
    StringBuilder text = new StringBuilder();
    text.append("\n\t\tClass:         " + this.getClass().getName() + "\n");
    text.append("\t\tDocument root:  " + documentRoot + "\n");
    text.append("\t\tFile extension: " + fileExtension);
    return text.toString();
  }
}
